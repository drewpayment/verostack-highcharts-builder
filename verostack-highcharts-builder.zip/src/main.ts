import { AppModule } from './app';

import 'url-search-params-polyfill';

new AppModule();
